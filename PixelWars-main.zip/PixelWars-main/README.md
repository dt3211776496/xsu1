# Super simple POC of r/place (work in progress)

In the real r/place april 1 event, app uses short pulling of reddits cdn (hot-potato).
Wanted to try to make a copy at the app with WebSockets.

- Server is based on nodejs and ws package
- Client-cli is console based client
- Client is react spa app
